## vue-lunar-full-calendar
```
a vue component for lunar fullcalendar. Uses Moment.js for date operations.
Increase the functions of Chinese lunar calendar, 24 solar terms and holidays(增加中国农历、24节气和节假日的功能)
```

## Installation
```
npm install --save vue-lunar-full-calendar
```

## Example App
I have created a simple Vue 2 webpack application as an example/playground
https://github.com/a306916069/vue-lunar-fullcalendar
## Image
```
a vue component for lunar fullcalendar. Uses Moment.js for date operations.
Increase the functions of Chinese lunar calendar, 24 solar terms and holidays(增加中国农历、24节气和节假日的功能)
```
![Image text](https://raw.githubusercontent.com/a306916069/vue-lunar-fullcalendar/master/src/assets/img/lunar.png)

## Important function
Use vue-lunar-full-calendar , You can use one function to get the date of a certain day.
```html
<lunar-full-calendar :events="events"></lunar-full-calendar>
...
<script>
...
  window.lunar(date)   // Date is the date.
...
</script>
```
![Image text](https://raw.githubusercontent.com/a306916069/vue-lunar-fullcalendar/master/src/assets/img/window.lunar.png)